# k8s-bluegreen
Harness Blue green deployment details
